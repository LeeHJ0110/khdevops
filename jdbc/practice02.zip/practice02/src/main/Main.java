package main;

public class Main {

	public static String loginMemberId = "admin";

	public static void main(String[] args) throws Exception {

		new ProgramManager().process();

	}

}
