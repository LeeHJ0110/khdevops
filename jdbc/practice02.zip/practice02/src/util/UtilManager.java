package util;

import java.util.Scanner;

public class UtilManager {
	
	public static final Scanner SC = new Scanner(System.in);
	
	public static int scanNum() {
		return Integer.parseInt(SC.nextLine());
	}
	

}
